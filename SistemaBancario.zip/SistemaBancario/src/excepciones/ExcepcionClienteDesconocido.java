/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package excepciones;

/**
 *
 * @author orlando
 */
public class ExcepcionClienteDesconocido extends Exception{

    public ExcepcionClienteDesconocido(String mensajeError) {
        super(mensajeError);
    }

}
