/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemabancario;

import java.util.Random;

/**
 *
 * @author orlando
 */
public class Cliente {
    private int id;
    private int calificacionCredito;

    public Cliente(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public int getCalificacionCredito() {
        return calificacionCredito;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setCalificacionCredito(int calificacionCredito) {
        this.calificacionCredito = calificacionCredito;
    }
    
    public void determinarEvaluacionCredito(){
        Random r = new Random();
        this.calificacionCredito = r.nextInt(100);
    }
    
    

    
    
    
}
