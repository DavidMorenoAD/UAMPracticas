/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemabancario;

import excepciones.*;

/**
 *
 * @author orlando
 */
public class ListaClientes {
    private Cliente[] listaClientes;

    //Constructor
    public ListaClientes(int numeroClientes) {
        listaClientes = new Cliente[numeroClientes];
        for(int i=0; i<numeroClientes; i++){
            listaClientes[i] = new Cliente(i);
            listaClientes[i].determinarEvaluacionCredito();
        }
    }


    public Cliente getCliente(int idCliente) throws ExcepcionClienteDesconocido{
        for(int i=0; i<listaClientes.length; i++){
            if(listaClientes[i].getId()== idCliente)
                return listaClientes[i];
        }
            // En lugar de return null ponemos la siguiente línea
            // return null;
            throw new ExcepcionClienteDesconocido("El objeto de tipo Cliente"
                    + " al que se quiere acceder no existe.");
    }

}
