/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sistemabancario;

import excepciones.ExcepcionClienteDesconocido;

/**
 *
 * @author orlando
 */
public class SistemaBancario {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws ExcepcionClienteDesconocido {
        // TODO code application logic here
         int iDCliente = 2000;
        try{
            ListaClientes listaClientes = new ListaClientes(500);
            Cliente cliente = listaClientes.getCliente(iDCliente);
            int calificacionCliente = cliente.getCalificacionCredito();
            if(calificacionCliente < 50){
                System.out.println("El cliente con calificación "+calificacionCliente+""
                        + " NO puede recibir préstamo");
            }
            else{
                System.out.println("El cliente con calificación "+calificacionCliente""
                                    + "puede recibir préstamo");
            }
        }
        catch(ExcepcionClienteDesconocido excepcinDeClienteDesconocido){
            System.out.println("El cliente con el id "+iDCliente+" especificado no existe"
                    + "en la base de datos");
        }









    }

}
