/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica3;

import java.util.Random;

/**
 *
 * @author Alumnos
 */
public class HillClimbing {
    /*
    Propiedades de hillClimbing 
    
    Las "iteraciones1,2 y 3" son valores en x que seran ocupados para llenar la tabla de VentanaHillClimbing
    */
    private double iteracion1;
    private double iteracion2;
    private double iteracion3; 
    
    public double hillClimbingV1(int opcion, double min,double max){
        
        //min,max: valores minimo y maximo de X
        int iteracion = 0;
        double solucionActual = generaSolucionAleatoria(min,max);
        double solucionNueva;
        do {            
            solucionNueva = generaSolucion(solucionActual, min, max);
            if (f(opcion, solucionNueva) > f(opcion, solucionActual)) {
                solucionActual = solucionNueva;
            }
            // Llenado de las iteraciones (valores en x)     
            if(iteracion == 0){
                iteracion1 = f(opcion, solucionActual);
            }
            if(iteracion == 1){
                iteracion2 = f(opcion, solucionActual);
            }
            if(iteracion == 2){
                iteracion3 = f(opcion, solucionActual);
            }
            iteracion++;
        } while (iteracion < 3); // pasen 3 iteaciones sin mejora);
        return solucionActual;
    }
    
    public double steepestHillClimbing(int opcion, int m,double min,double max){
        
        // m: maximo n�mero de vecinos que se crear�n 
        int iteraciones = 0;
        double solucionActual = generaSolucionAleatoria(min,max);
        double solucionNueva;
        do {            
            double solucionTemporal = generaSolucion(solucionActual,min,max);
            for (int i = 0; i < m; i++) {
                solucionNueva = generaSolucion(solucionActual,min,max);
                if (f(opcion, solucionTemporal) < f(opcion, solucionNueva))
                    solucionTemporal = solucionActual;
            }
            if (f(opcion, solucionTemporal) > f(opcion, solucionActual)) {
                solucionActual = solucionTemporal;
            }
            if(iteraciones == 0){
                iteracion1 = f(opcion, solucionActual);
            }
            if(iteraciones == 1){
                iteracion2 = f(opcion, solucionActual);
            }
            if(iteraciones == 2){
                iteracion3 = f(opcion, solucionActual);
            }
            iteraciones ++;
        } while (iteraciones < 3);
        return solucionActual;
    }
    
    public double stepestHillClimbingReplacemenet(int opcion, int m,double min,double max){
        int iteraciones = 0;
        double solucionActual = generaSolucionAleatoria(min, max);
        double mejor = solucionActual;
        double solucionNueva;
        double solucionTemporal;
        
        do {            
            solucionTemporal = generaSolucion(solucionActual, min, max);
            for (int i = 0; i < m; i++) {
                solucionNueva = generaSolucion (solucionActual, min, max);
                if (f(opcion, solucionNueva) > f(opcion, solucionTemporal)) {
                        solucionTemporal = solucionNueva;
                    }
            }
            solucionActual = solucionTemporal;
            if (f(opcion, solucionActual) > f(opcion, mejor)) {
                mejor = solucionActual;
            }
            if(iteraciones == 0){
                iteracion1 = f(opcion, solucionActual);
            }
            if(iteraciones == 1){
                iteracion2 = f(opcion, solucionActual);
            }
            if(iteraciones == 2){
                iteracion3 = f(opcion, solucionActual);
            }
            iteraciones ++;
        } while (iteraciones < 3);
        return mejor;
    }
    
    public double generaSolucionAleatoria(double min, double max){
        double solucion = (double) (Math.random() * max) + min;
        return solucion;
    }
    
    public double generaSolucion(double solucion, double min, double max){
        Random numAleatorio = new Random();

        // Genera un boolean de forma aleatoria
        boolean rand = numAleatorio.nextBoolean();

        // Si es verdadero suma, si no resta
        if (rand) {
            if (solucion++ <= max) {
                solucion++;
            } else {
                solucion = generaSolucion(solucion, min, max);
            }
        } else {
            if (rand) {
                solucion--;
            } else {
                solucion = generaSolucion(solucion, min, max);
            }
        }
        return solucion;
    }
    
    public double f (int opcion, double x){
        if (opcion == 1) {
            return Math.sin(x) + Math.sin((10/3)*x);
        }else{
            return Math.sin((x*x)/10)/((x*x)/10); 
        }
    }
    
    // GETTERS Y SETTERS DE LAS ITERACIONES
    
    public double getIteracion1() {
        return iteracion1;
    }

    public void setIteracion1(double iteracion1) {
        this.iteracion1 = iteracion1;
    }

    public double getIteracion2() {
        return iteracion2;
    }

    public void setIteracion2(double iteracion2) {
        this.iteracion2 = iteracion2;
    }

    public double getIteracion3() {
        return iteracion3;
    }

    public void setIteracion3(double iteracion3) {
        this.iteracion3 = iteracion3;
    }
}
