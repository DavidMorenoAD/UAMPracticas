/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg8puzzle;

import java.util.ArrayList;

/**
 *
 * @author David & Fidel
 */
/**
    CLASE TABLERO
    * CUYOS ATRIBUTO ES SU UNA MATRIZ DE ENTEROS "CONFIGURACIÓN"
    * SU METODO ES GENERA ESTADOS VECINOS QUE DEVUELVE UN ARRAYLIST DE MATRICES DE 3 POR 3
 
 */
public class Tablero{
    public int[][] configuracion = new int[3][3];
    private ArrayList<int[][]> estadosVecinos = new ArrayList();
    
    // MÉTODO PARA GENERAR LOS POSIBLES ESTADOS, DEVUELVE UN ARRAYLIST
    
    public ArrayList generaEstadosVecinos(int[][] estadoVecino){
        int[][] aux1 = new int[3][3];
        int[][] aux2 = new int[3][3];
        int[][] aux3 = new int[3][3];
        int[][] aux4 = new int[3][3];
        
            // CASO 1: QUE EL ESPACIO DEL PUZZLE ESTE EN EL CENTRO
            
            if( estadoVecino[1][1] == 0){
                for (int a = 0; a < 3; a++) {
                    System.arraycopy(estadoVecino[a], 0, aux1[a], 0, 3);
                }

                aux1[1][1] = estadoVecino[1][0];
                aux1[1][0] = 0;
                estadosVecinos.add(aux1);

                for (int a = 0; a < 3; a++) {
                    System.arraycopy(estadoVecino[a], 0, aux2[a], 0, 3);
                }
                aux2[1][1] = estadoVecino[0][1];
                aux2[0][1] = 0;
                estadosVecinos.add(aux2);
                
                for (int a = 0; a < 3; a++) {
                    System.arraycopy(estadoVecino[a], 0, aux3[a], 0, 3);
                }

                aux3[1][1] = estadoVecino[1][2];
                aux3[1][2] = 0;
                estadosVecinos.add(aux3);

                for (int a = 0; a < 3; a++) {
                    System.arraycopy(estadoVecino[a], 0, aux4[a], 0, 3);
                }
                aux4[1][1] = estadoVecino[2][1];
                aux4[2][1] = 0;
                estadosVecinos.add(aux4);

            }
            
            // CASO 2: QUE EL ESPACIO DEL PUZZLE ESTE EN UNA ESQUINA
            
            else if ( estadoVecino[0][0] == 0 ){
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(estadoVecino[a], 0, aux1[a], 0, 3);
                    }

                    aux1[0][0] = estadoVecino[0][1];
                    aux1[0][1] = 0;
                    estadosVecinos.add(aux1);
                    
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(estadoVecino[a], 0, aux2[a], 0, 3);
                    }

                    aux2[0][0] = estadoVecino[1][0];
                    aux2[1][0] = 0;
                    estadosVecinos.add(aux2);
            }

            else if ( estadoVecino[0][2] == 0 ){
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(estadoVecino[a], 0, aux1[a], 0, 3);
                    }

                    aux1[0][2] = estadoVecino[0][1];
                    aux1[0][1] = 0;
                    estadosVecinos.add(aux2);
                    
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(estadoVecino[a], 0, aux2[a], 0, 3);
                    }

                    aux2[0][2] = estadoVecino[1][2];
                    aux2[1][2] = 0;
                    estadosVecinos.add(aux2);
            }
            
            else if ( estadoVecino[2][0] == 0 ){
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(estadoVecino[a], 0, aux1[a], 0, 3);
                    }

                    aux1[2][0] = estadoVecino[1][0];
                    aux1[1][0] = 0;
                    estadosVecinos.add(aux1);
                    
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(estadoVecino[a], 0, aux2[a], 0, 3);
                    }

                    aux2[2][0] = estadoVecino[2][1];
                    aux2[2][1] = 0;
                    estadosVecinos.add(aux2);
            }

            else if ( estadoVecino[2][2] == 0 ){
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(estadoVecino[a], 0, aux1[a], 0, 3);
                    }

                    aux1[2][2] = estadoVecino[1][2];
                    aux1[1][2] = 0;
                    estadosVecinos.add(aux1);
                    
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(estadoVecino[a], 0, aux2[a], 0, 3);
                    }

                    aux2[2][2] = estadoVecino[2][1];
                    aux2[2][1] = 0;
                    estadosVecinos.add(aux2);
            }
            
            // CASO 3: QUE EL ESPACIO DEL PUZZLE ESTE EN UNA ARISTA
            
            else if ( estadoVecino[0][1] == 0 ){
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(estadoVecino[a], 0, aux1[a], 0, 3);
                    }

                    aux1[0][1] = estadoVecino[0][0];
                    aux1[0][0] = 0;
                    estadosVecinos.add(aux1);
                    
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(estadoVecino[a], 0, aux2[a], 0, 3);
                    }

                    aux2[0][1] = estadoVecino[0][2];
                    aux2[0][2] = 0;
                    estadosVecinos.add(aux2);
                    
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(estadoVecino[a], 0, aux3[a], 0, 3);
                    }

                    aux3[0][1] = estadoVecino[1][1];
                    aux3[1][1] = 0;
                    estadosVecinos.add(aux3);
            }

            else if ( estadoVecino[2][1] == 0 ){
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(estadoVecino[a], 0, aux1[a], 0, 3);
                    }

                    aux1[2][1] = estadoVecino[2][0];
                    aux1[2][0] = 0;
                    estadosVecinos.add(aux1);
                    
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(estadoVecino[a], 0, aux2[a], 0, 3);
                    }

                    aux2[2][1] = estadoVecino[2][2];
                    aux2[2][2] = 0;
                    estadosVecinos.add(aux2);
                    
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(estadoVecino[a], 0, aux3[a], 0, 3);
                    }

                    aux3[2][1] = estadoVecino[1][1];
                    aux3[1][1] = 0;
                    estadosVecinos.add(aux3);
            }
            
            else if ( estadoVecino[1][0] == 0 ){
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(estadoVecino[a], 0, aux1[a], 0, 3);
                    }

                    aux1[1][0] = estadoVecino[0][0];
                    aux1[0][0] = 0;
                    estadosVecinos.add(aux1);
                    
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(estadoVecino[a], 0, aux2[a], 0, 3);
                    }

                    aux2[1][0] = estadoVecino[2][0];
                    aux2[2][0] = 0;
                    estadosVecinos.add(aux2);
                    
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(estadoVecino[a], 0, aux3[a], 0, 3);
                    }

                    aux3[1][0] = estadoVecino[1][1];
                    aux3[1][1] = 0;
                    estadosVecinos.add(aux3);
            }

            else if ( estadoVecino[1][2] == 0 ){
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(estadoVecino[a], 0, aux1[a], 0, 3);
                    }

                    aux1[1][2] = estadoVecino[0][2];
                    aux1[0][2] = 0;
                    estadosVecinos.add(aux1);
                    
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(estadoVecino[a], 0, aux2[a], 0, 3);
                    }

                    aux2[1][2] = estadoVecino[2][2];
                    aux2[2][2] = 0;
                    estadosVecinos.add(aux2);
                    
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(estadoVecino[a], 0, aux3[a], 0, 3);
                    }

                    aux3[1][2] = estadoVecino[1][1];
                    aux3[1][1] = 0;
                    estadosVecinos.add(aux3);
            }
        return estadosVecinos;
    }
    
        //  MÉTODO PARA IMPRIMIR LOS ESTADOS VECINOS EN PANTALLA
    
    public void imprimeEstadosVecinos(){
        for (int a = 0; a < estadosVecinos.size(); a++) {
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    System.out.print(estadosVecinos.get(a)[i][j]+" ");
                }
                System.out.println("");
            }
            System.out.println("");
        }
    }
    
        //MÉTODO PARA IMPRIMIR UN ARREGLO DE ENTEROS DADO
    
    public void imprime(int[][] e) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(e[i][j] + " ");
            }
            System.out.println("");
        }
    }
}
