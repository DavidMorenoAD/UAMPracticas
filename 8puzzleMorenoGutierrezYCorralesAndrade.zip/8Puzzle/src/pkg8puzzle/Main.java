/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg8puzzle;

/**
 *
 * @author David & Fidel
 */
public class Main {

    /**
     * PRUEBA DE 8-PUZZLE
     * 
     * @param args
     */
    public static void main(String[] args) {
        int[][] estadoInicial = new int[3][3];
        int[][] estadoFinal = new int[3][3];
        int n = 1;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                estadoFinal[i][j] = n++;
            }
        }
        estadoFinal[2][2] = 0;
        
        estadoInicial[0][0] = 2;
        estadoInicial[0][1] = 6;
        estadoInicial[0][2] = 5;
        estadoInicial[1][0] = 7;
        estadoInicial[1][1] = 0;
        estadoInicial[1][2] = 4;
        estadoInicial[2][0] = 3;
        estadoInicial[2][1] = 1;
        estadoInicial[2][2] = 8;
        
        Tablero Tab = new Tablero();
        Tab.configuracion = estadoInicial;

        Tab.generaEstadosVecinos(estadoInicial);
        Tab.imprimeEstadosVecinos();
    }
    
}
