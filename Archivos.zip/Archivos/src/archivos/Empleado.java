/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package archivos;

/**
 *
 * @author magicorlan
 */
public class Empleado implements Comparable<Empleado>{

	private int id;
	private String nombre;
	private String puesto;
	private int salario;
	
        public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getPuesto() {
		return puesto;
	}
	public void setPuesto(String puesto) {
		this.puesto = puesto;
	}
	public int getSalario() {
		return salario;
	}
	public void setSalario(int salario) {
		this.salario = salario;
	}
	
	@Override
	public String toString(){
		return "\nID = "+getId()+" -  Nombre = "+getNombre()+" - Puesto = "+getPuesto()+" - Salario = "+getSalario();
	}
        
        
    public int compareTo(Empleado empleado){
        if(this.salario > empleado.salario)
            return 1;
        else if(this.salario < empleado.salario)
            return -1;
        else
            return 0;
    }
    

}
