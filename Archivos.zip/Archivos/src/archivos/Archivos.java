/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package archivos;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Scanner;

/**
 *
 * @author magicorlan
 */
public class Archivos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        /*
            Esta clase permite crear objetos que leen archivos
        */
        BufferedReader lector = new BufferedReader(new FileReader("empleados.csv"));
        
        
        /*
            Para leer el archivo separado por comas, necesitaremos una variable
            de tipo String llamada renglon que va a contener cada renglón
            léido desde el archivo csv. Necesitamos un objeto de tipo Scanner
            para que almacene temporalmente cada renglón y separar cada
            dato. Y necesitamos
            un ArrayList para contener cada empleado (renglón leído desde el
            archivo).
        */
        String renglon = null;
        Scanner scanner = null;
        int indice = 0;
        List<Empleado> listaEmpleados = new ArrayList<>();
        
        /*
            Mientras la línea leída desde el archivo sea diferente de null:
            * Crea un nuevo empleado temporal para almacenar los que se leen desde archivo
            * Asignamos al scanner el renglón leído por el lector
            * Le decimos a scanner cuál es el carácter con el que se separa cada dato en el renglón.
              En inglés a este carácter se le llama delimitador (Delimiter).
            * Por cada renglón leído se realiza lo que hay en el while interno
        */
        while( (renglon = lector.readLine()) != null){
            Empleado empleado = new Empleado();
            scanner = new Scanner(renglon);
            scanner.useDelimiter(",");
            
            /*
                Mientras haya en el renglón (lo que tiene actualmente scanner):
                * Si indice es igual a 0 significa que el dato leído por scanner.next()
                es el Id del empleado y se asigna a empleado.
                al objeto empleado creado anteriormente.
                * Si índice es igual a 1 entonces el siguiente dato léido es el nombre
                del empleado y éste se asigna al objeto empleado
                * Si el índice es igual a 2 entonces el dato leido es el puesto del empleado
                y se le asigna al objeto empleado
                * Si el índice es igual a 3 entonces el dato leído es el salario del empleado
                y se le asigna al objeto empleado
                * Incrementamos el índice.
            */
            while(scanner.hasNext()){
                String dato = scanner.next();
                if(indice == 0)
                    empleado.setId(Integer.parseInt(dato));
                else if(indice == 1)
                    empleado.setNombre(dato);
                else if(indice == 2)
                    empleado.setPuesto(dato);
                else if(indice == 3)
                    empleado.setSalario(Integer.parseInt(dato));
                indice++;
            }
            /*
                Reiniciamos el índice para el siguiente renglón
                y agregamos el objeto empleado, con los datos leídos
                en el renglón actual, a la lista de empleados
            */
            indice = 0;
            listaEmpleados.add(empleado);
        }
        // Cerramos el archivo
        lector.close();
        
        /*
            Imprimimos en pantalla los empleados
        */
        System.out.println("Array list de empleados ");
        for(Empleado empleadoTemporal: listaEmpleados)
            System.out.println(empleadoTemporal.toString());
        
        
        
        PriorityQueue<Empleado> colaEmpleados =  new PriorityQueue<>();
        for(Empleado empleado: listaEmpleados)
            colaEmpleados.add(empleado);


        
        System.out.println();
        System.out.println();
        System.out.println("Cola prioritaria de empleados ");
        for(Empleado empleadoTemporal2: colaEmpleados)
            System.out.println(empleadoTemporal2.toString());        
        
        
        
    }
}
