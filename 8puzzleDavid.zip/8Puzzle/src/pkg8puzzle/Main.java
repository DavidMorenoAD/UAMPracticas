/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg8puzzle;

import java.util.ArrayList;

/**
 *
 * @author David Moreno
 */
public class Main {

    /**
     * PRUEBA DE 8-PUZZLE
     */
    public static void main(String[] args) {
        int[][] t = new int[3][3];
        
        t[0][0] = 0;
        t[0][1] = 6;
        t[0][2] = 5;
        t[1][0] = 7;
        t[1][1] = 2;
        t[1][2] = 4;
        t[2][0] = 3;
        t[2][1] = 1;
        t[2][2] = 8;
        Tablero Tab = new Tablero();
        Tab.configuracion = t;

        Tab.generaEstadosVecinos();

    }
    
}
