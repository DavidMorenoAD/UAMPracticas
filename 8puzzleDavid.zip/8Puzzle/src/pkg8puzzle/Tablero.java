/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg8puzzle;

import java.util.ArrayList;

/**
 *
 * @author David Moreno and Fidel
 */
/**
    CLASE TABLERO
    * CUYOS ATRIBUTO ES SU UNA MATRIZ DE ENTEROS "CONFIGURACIÓN"
    * SU METODO ES GENERA ESTADOS VECINOS QUE DEVUELVE UN ARRAYLIST DE MATRICES DE 3 POR 3
 
 */
public class Tablero{
    public int[][] configuracion = new int[3][3];
    ArrayList<int[][]> estadosVecinos = new ArrayList();
    public ArrayList generaEstadosVecinos(){
        int[][] aux = new int[3][3];

            // CASO 1: QUE EL ESPACIO DEL PUZZLE ESTE EN EL CENTRO
            
            if( configuracion[1][1] == 0){
                for (int k = 0; k <= 2; k = k+2) {

                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(configuracion[a], 0, aux[a], 0, 3);
                    }

                    aux[1][1] = configuracion[1][k];
                    aux[1][k] = 0;
                    estadosVecinos.add(aux);
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(configuracion[a], 0, aux[a], 0, 3);
                    }
                    aux[1][1] = configuracion[k][1];
                    aux[k][1] = 0;
                    estadosVecinos.add(aux);
                }
            }
            
            // CASO 2: QUE EL ESPACIO DEL PUZZLE ESTE EN UNA ESQUINA
            
            else if ( configuracion[0][0] == 0 ){
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(configuracion[a], 0, aux[a], 0, 3);
                    }

                    aux[0][0] = configuracion[0][1];
                    aux[0][1] = 0;
                    estadosVecinos.add(aux);
                    
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(configuracion[a], 0, aux[a], 0, 3);
                    }

                    aux[0][0] = configuracion[1][0];
                    aux[1][0] = 0;
                    estadosVecinos.add(aux);
            }

            else if ( configuracion[0][2] == 0 ){
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(configuracion[a], 0, aux[a], 0, 3);
                    }

                    aux[0][2] = configuracion[0][1];
                    aux[0][1] = 0;
                    estadosVecinos.add(aux);
                    
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(configuracion[a], 0, aux[a], 0, 3);
                    }

                    aux[0][2] = configuracion[1][2];
                    aux[1][2] = 0;
                    estadosVecinos.add(aux);
            }
            
            else if ( configuracion[2][0] == 0 ){
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(configuracion[a], 0, aux[a], 0, 3);
                    }

                    aux[2][0] = configuracion[1][0];
                    aux[1][0] = 0;
                    estadosVecinos.add(aux);
                    
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(configuracion[a], 0, aux[a], 0, 3);
                    }

                    aux[2][0] = configuracion[2][1];
                    aux[2][1] = 0;
                    estadosVecinos.add(aux);
            }

            else if ( configuracion[2][2] == 0 ){
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(configuracion[a], 0, aux[a], 0, 3);
                    }

                    aux[2][2] = configuracion[1][2];
                    aux[1][2] = 0;
                    estadosVecinos.add(aux);
                    
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(configuracion[a], 0, aux[a], 0, 3);
                    }

                    aux[2][2] = configuracion[2][1];
                    aux[2][1] = 0;
                    estadosVecinos.add(aux);
            }
            
            // CASO 3: QUE EL ESPACIO DEL PUZZLE ESTE EN UNA ARISTA
            
            else if ( configuracion[0][1] == 0 ){
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(configuracion[a], 0, aux[a], 0, 3);
                    }

                    aux[0][1] = configuracion[0][0];
                    aux[0][0] = 0;
                    estadosVecinos.add(aux);
                    
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(configuracion[a], 0, aux[a], 0, 3);
                    }

                    aux[0][1] = configuracion[0][2];
                    aux[0][2] = 0;
                    estadosVecinos.add(aux);
                    
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(configuracion[a], 0, aux[a], 0, 3);
                    }

                    aux[0][1] = configuracion[1][1];
                    aux[1][1] = 0;
                    estadosVecinos.add(aux);
            }

            else if ( configuracion[2][1] == 0 ){
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(configuracion[a], 0, aux[a], 0, 3);
                    }

                    aux[2][1] = configuracion[2][0];
                    aux[2][0] = 0;
                    estadosVecinos.add(aux);
                    
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(configuracion[a], 0, aux[a], 0, 3);
                    }

                    aux[2][1] = configuracion[2][2];
                    aux[2][2] = 0;
                    estadosVecinos.add(aux);
                    
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(configuracion[a], 0, aux[a], 0, 3);
                    }

                    aux[2][1] = configuracion[1][1];
                    aux[1][1] = 0;
                    estadosVecinos.add(aux);
            }
            
            else if ( configuracion[1][0] == 0 ){
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(configuracion[a], 0, aux[a], 0, 3);
                    }

                    aux[1][0] = configuracion[0][0];
                    aux[0][0] = 0;
                    estadosVecinos.add(aux);
                    
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(configuracion[a], 0, aux[a], 0, 3);
                    }

                    aux[1][0] = configuracion[2][0];
                    aux[2][0] = 0;
                    estadosVecinos.add(aux);
                    
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(configuracion[a], 0, aux[a], 0, 3);
                    }

                    aux[1][0] = configuracion[1][1];
                    aux[1][1] = 0;
                    estadosVecinos.add(aux);
            }

            else if ( configuracion[1][2] == 0 ){
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(configuracion[a], 0, aux[a], 0, 3);
                    }

                    aux[1][2] = configuracion[0][2];
                    aux[0][2] = 0;
                    estadosVecinos.add(aux);
                    
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(configuracion[a], 0, aux[a], 0, 3);
                    }

                    aux[1][2] = configuracion[2][2];
                    aux[2][2] = 0;
                    estadosVecinos.add(aux);
                    
                    for (int a = 0; a < 3; a++) {
                        System.arraycopy(configuracion[a], 0, aux[a], 0, 3);
                    }

                    aux[1][2] = configuracion[1][1];
                    aux[1][1] = 0;
                    estadosVecinos.add(aux);
            }
        return estadosVecinos;
    }
/**
    public void imprimeEstadosVecinos(){
        for (int a = 0; a < estadosVecinos.size(); a++) {
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    System.out.print(estadosVecinos.get(a)[i][j]);
                }
                System.out.println("");
            }
        }
        System.out.println("");
    }
    public void imprime(int[][] e) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(e[i][j] + " ");
            }
            System.out.println("");
        }
    }
*/
}
