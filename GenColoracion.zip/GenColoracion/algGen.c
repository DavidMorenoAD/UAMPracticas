//***************************************************
//  PROGRAMA QUE RESUELVE EL PROBLEMA DE COLORACION
//  DE GRAFOS USANDO ALGORITMO GENÉTICO
//
//  DESARROLLADO POR:
//
//  LUIS ALFREDO PÉREZ MENDOZA
//  DAVID MORENO GUTIÉRREZ
//  SARAHI SOTO PALAFOX
//
//  UNIVERSIDAD AUTÓNOMA METROPOLITANA
//          UNIDAD IZTAPALAPA
//
//***************************************************


#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<time.h>
typedef char chain[256];

// -------- MODULO PARA LA CREACION DE LA LISTA LIGADA---------------//
//
struct Node //DECLARACION DE LA ESTRUCTURA
{
        int num;
        struct Node* next;
};
void add_nodes(struct Node **head, int num)
{
	//ESTA FUNCION AGREGA NODOS AL ARREGLO DE LA LISTA LIGADA
        struct Node *aux_node=(struct Node *)malloc(sizeof(struct Node));
        aux_node->num = num;
        aux_node->next=NULL;
        if(*head==NULL)
        {
                *head = aux_node;
        }
        else
        {
                struct Node *p;
                p = *head;
                while(p->next!=NULL)
                {
                        p = p->next;

                }
                p->next=aux_node;
        }

}
void disp_ad_matrix(struct Node **admat,int n_reg)
{
	//ESTA FUNCIÓN DESPLIEGA AL ARREGLO DE LA LISTA LIGADA
	int i=0;
        for(int k=0; k<n_reg; k++)
        {

        	struct Node *current;
                for(current=*admat; current!=NULL; current = current->next)
                {
                       	printf("%d -->\t",current->num);

                }
		admat++;
                printf("%s","NULL");
                printf("\n");
        }

}
//
// --------FIN DEL MUDULO DE ARREGLOS DE LA LISTA LIGADA---------------//
//
// --------- MODULOS PARA CREAR MATRICES DE DOS DIMENCIONES ---------------------------//
// --------- USADA PARA INICIALIZAR LA MATRIZ DE POBLACION----------------------------//
//
int **create_matrix(int n_ind,int n_reg)
{
	//ESTA FUNCION CREA UNA MATRIZ DE DOS DIMENSIONES
	int *p1 = NULL;
	int **p2 = NULL;

	p1 = (int *)malloc(sizeof(int)*(n_ind*n_reg));
	if(p1!=NULL)
	{
		p2=(int **)malloc(sizeof(int *)*n_ind);
		if(p2!=NULL)
		{
			for(int i=0; i<n_ind; i++)
			{
				p2[i] = &(p1[i*n_reg]);



			}
		}
		else{printf("NO MEMORY\n");}
	}
	else{printf("NO MEMORY\n");}

	return p2;

}
void display_pop(int **point2, int n_ind, int n_reg)
{
	// ESTE PROCEDIMIENTO DESPLIEGA LA MATRIZ DE POBLACION
        printf("TU MATRIZ CON %d INDIVIDUOS Y %d REGIONES A COLOREAR ES:\n",n_ind,n_reg);
        for(int i=0; i<n_ind; i++)
        {
                 printf("ind[%d] \t",i);
                for(int j=0; j<n_reg; j++)
                {
                        printf("[%d]\t",point2[i][j]);
                }
                        printf("\n");
        }
}
void generate_rand_pop(int **p2,int n_ind,int n_reg,int colour)
{
	//ESTE PROCEDIMIENTO CREA LA PRIMERA POBLACION ALEATORIAMENTE
	for(int i=0; i<n_ind; i++)
	{
		for(int j=0; j<n_reg; j++)
		{
			p2[i][j] = rand()%colour;
		}
	}


}
//--------------- FIN DEL MUDULO PARA CREAR LA MATRIS DE POBLACION--------------------------------//
//
// ------------ MÓDULOS PARA CALCULAR EL FITNESS -----------------------------------------------------//
// ------------- USANDO LA MATRIZ DE ADJACENCIA -------------------------------------------------------//
int get_sum(int **pop,struct Node **admat,int n_reg,int iter)
{
 	int count = 0;
	for(int k=0; k<n_reg; k++)
	{
		struct Node *current;
		for(current=*admat; current!=NULL; current = current->next)
		{
			if(pop[iter][k]==pop[iter][current->num])
			{
				count = count + 1;
			}
		}
		admat++;
	}
	return count;
}
void get_fitness(int **pop,struct Node **admat,int fitness[],int n_ind,int n_reg)
{
	//ESTE MODULO CALCULA EL FITNESS DE UN INDIVIDUO EN LA
	//MATRIZ DE POBLACION: REGRESA EL FITNESS DEL ARREGLO LLENADO
	int i,j,count;
	int value;
	i=0; //Indice para el número de individuos en la población
	//count = 0;
	do
	{
		value = get_sum(pop,admat,n_reg,i);
		fitness[i]=value;
		i++;
	}while(i<n_ind);
}
void get_ad_matrix(struct Node **admat,int n_reg,chain filename)
{
	// ESTE MODULO OBTIENE LA MATRIZ DE LA MATRIZ DE ADYACENCIA DEL
	// LA CONEXION DE GRAFOS EN EL ARCHIVO LEIDO
	FILE *input;
	int k=0,j=0,num,Nreg;
        if((input = fopen(filename,"r"))==NULL)
        {
                printf("ERROR AL ABRIR EL ARCHIVO\n");
        }
        fscanf(input,"%d%*[^\n]\n",&Nreg);
	if(n_reg!=Nreg)
	{
		printf("ARCHIVO EQUIVOCADO: EL NUMERO DE REGIONES ES DIFERENTE AL NUMERO EN EL ARCHIVO\n");
	}
        for(int i=0;i<n_reg; i++)
        {
                admat[i] = NULL;
        }
        fscanf(input,"%d",&num);
        while(!feof(input))
        {
                if(num!=-1)
                {
                        j=num;
                        add_nodes(&admat[k],j);
                        j++;
                }
                else
                {
                        k++;
                }
                fscanf(input,"%d",&num);

        }
        fclose(input);

}
// ------------ FIN DEL MODULO PARA CALCULAR EL FITNESS--------------------------------------//
//
// ------- MODULO PARA OBTENER EL MEJOR FITNESS-------------------------------------------------------//
int get_best(int **pop,int fitness[],int mejor_ind[],int n_ind,int n_reg,int *prueba)
{
    int i,indiv,mejor;
    mejor = fitness[0];
    indiv=0;
    for(int i=1; i<(n_ind)-1; i++)
    {
        if(fitness[i]<mejor) //fitness i es el fitness del i-esimo individuo
        {
            mejor = fitness[i];
            *prueba = i;
            indiv = i;
        }
    }
    printf("fitness = %d\n",mejor);
    //printf("LA SOLUCION ES:\n");
    for(int j=0; j<n_reg; j++)
    {
        mejor_ind[j] = pop[indiv][j];
	//printf("%d\n",mejor_ind[j]);
    }

    return mejor;
}
// ------- FIN DEL MODULO PARA OBTENER EL MEJOR FITNESS----------------------------------------------------//
//
//
//
void mutation(int **aux_pop,int n_ind,int n_reg,int n_colour )
{

	int rnd_reg,rnd_color;
	for(int i=0; i<n_ind; i++)
	{
		rnd_reg = rand()%n_reg;
		rnd_color = rand()%n_colour;
		aux_pop[i][rnd_reg] = rnd_color;

	}


}
void cruzamiento(int **point2, int **point2_aux, int n_ind, int n_reg)
{
     int cruz_point;

     cruz_point=rand()%(n_reg-1)+1; //crea el punto de cruzamiento


      for(int i=0; i<n_ind; i++)
        {
                for(int j=0; j<cruz_point; j++)
                {
                    point2_aux[i][j]=point2[i][j];
                }

        }

       for(int i=0; i<n_ind; i=i+2) //llena el cruze en los pares
        {
                for(int j=cruz_point; j<n_reg; j++)
                {
                    point2_aux[i][j]=point2[i+1][j];

                }
        }

        for(int i=1; i<n_ind; i=i+2) //llena el cruze en los impares
        {
                for(int j=cruz_point; j<n_reg; j++)
                {
                    point2_aux[i][j]=point2[i-1][j];

                }
        }

}
void clonacion(int **pop, int **aux_pop, int n_ind, int n_reg){

    int i,j;

    for(i=0; i<n_ind; i++){
        for(j=0; j<n_reg; j++){
            aux_pop[i][j] = pop[i][j];
        }
    }

}
//
// ----------- MODULOS PARA COMPARAR NUEVAS SOLUCIONES ------------------------------------------//
//
void compara_mut(int aux_fitness[],int fitness[], int **pop, int **aux_pop,int n_ind, int n_reg)
{
   for(int i=0; i<n_ind; i++)
   {
      if(aux_fitness[i]<=fitness[i])
      {
         fitness[i] = aux_fitness[i];
         for(int j=0; j<n_reg; j++)
         {
            pop[i][j] = aux_pop[i][j];
         }
      }
   }
}
void compara_cruz(int aux_fitness[],int fitness[], int **pop, int **aux_pop,int n_ind, int n_reg)
{
   for(int i=0; i<n_ind; i++)
   {
      if(aux_fitness[i]<fitness[i])
      {
         fitness[i] = aux_fitness[i];
         for(int j=0; j<n_reg; j++)
         {
            pop[i][j] = aux_pop[i][j];
         }
      }
   }
}
// ------ FIN DEL MODULO PARA COMPARAR NUEVAS SOLUCIONES ------------------------------------//
int main ()
{	clock_t t_in,t_fin;
	double secs;
	srand(time(NULL));
        int **pop,**aux_pop,n_reg,n_ind,n_colour,best,M,N;
        int Nreg,bestInd;
        float probc, probm;
        FILE *input;
        chain filename;

        // **pop hace referencia a la poblacion;
        // population = Num de individuos y Num de regiones por colorear
        // n_ind -> almacen del numero de individuos
        // n_reg -> almacen del numero de regiones por colorear
        // n_col -> Numero de colores

        do
	{
		printf("INGRESE EL TAMAÑO DE LA POBLACIÓN\n");
        	scanf("%d",&n_ind);

	}while(n_ind%2!=0);
        printf("INGRESE EL TAMAÑO DEL COLOR DE REGIONES MxN\n");
        scanf("%d   %d",&M,&N);
        printf("INGRESE EL NUMERO DE COLORES\n");
        scanf("%d",&n_colour);
        printf("NOMBRE DEL ARCHIVO DEL GRAFO\n");
        scanf("%s",filename);
        printf("INSERTE PROBABILIDAD DE CRUZA (ENTRE 0.2 Y 0.8)\n");
        scanf("%f",&probc);
        printf("INSERTE PROBABILIDAD DE MUTACION(ENTRE 0.0 Y 0.1)\n");
        scanf("%f",&probm);
        printf("\n");
	n_reg = M*N;
	struct Node *admat[n_reg]; //Una estructura para guardar el arreglo de la lista ligada para la matriz de adyacencia
	int fitness[n_ind],mejor_ind[n_reg],aux_fitness[n_ind]; // Un arreglo para almacenar el fitness de cada individuo

	t_in = clock();
	get_ad_matrix(admat,n_reg,filename); //Obtiene la matriz de adyacencia
	disp_ad_matrix(admat,n_reg);// Muestra la matriz de adyacencia
	pop = create_matrix(n_ind,n_reg); //Guarda la memoria para la matriz poblacion
	aux_pop = create_matrix(n_ind,n_reg);
	generate_rand_pop(pop,n_ind,n_reg,n_colour); //Crea aleatoriamente la poblacion inicial
	display_pop(pop,n_ind,n_reg); // Despliega la matriz con la poblacion
	get_fitness(pop,admat,fitness,n_ind,n_reg);// calcula el fitness
	best = get_best(pop,fitness,mejor_ind,n_ind,n_reg,&bestInd);

	int N_gen=0;
	while(best!=0)
	{
		cruzamiento(pop,aux_pop,n_ind,n_reg);
		get_fitness(aux_pop,admat,aux_fitness,n_ind,n_reg);
		compara_cruz(aux_fitness,fitness,pop,aux_pop,n_ind,n_reg);
		best = get_best(pop,fitness,mejor_ind,n_ind,n_reg,&bestInd);
		if(best==0)
		{
			break;
		}
		clonacion(pop,aux_pop,n_ind,n_reg);
		mutation(aux_pop,n_ind,n_reg,n_colour);
		get_fitness(aux_pop,admat,aux_fitness,n_ind,n_reg);
		compara_mut(aux_fitness,fitness,pop,aux_pop,n_ind,n_reg);
		best = get_best(pop,fitness,mejor_ind,n_ind,n_reg,&bestInd);
        //display_pop(pop,n_ind,n_reg); // Despliega la matriz de poblacion
        //printf("el mejor individio de esta poblacion fue %d10\n" ,bestInd);
		N_gen++;


	}
	printf("SOLUCION ENCONTRADA DESPUÉS DE %d GENERACIONES Y FUE EL INDIVIDUO %d\n",N_gen,bestInd);

	int **sol;
	sol = create_matrix(M,N);
	int k=0;
	for(int i=0; i<M; i++)
	{
		for(int j=0; j<N;j++)
		{
			sol[i][j] = mejor_ind[k];
			k++;
			printf("%d   \t",sol[i][j]);
		}
		printf("\n");
	}

	t_fin = clock();

	secs = (double)(t_fin - t_in)/CLOCKS_PER_SEC;

	printf("EL TIEMPO TOTAL DE EJECUCIÓN ES %lf segundos \n", secs);


	return 0;

}
