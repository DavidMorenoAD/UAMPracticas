/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica3;

/**
 *
 * @author Alumnos
 */
public class HillClimbing {
    
    
    
    public double hillClimbingV1(double min,double max){
        
        //min,max: valores minimo y maximo de X
        int iteracion = 0;
        double solucionActual = generaSolucionAleatoria(min,max);
        double solucionNueva;
        do {            
            solucionNueva = generaSolucion(solucionActual, min, max);
            if (f(solucionNueva) > f(solucionActual)) {
                solucionActual = solucionNueva;
            }
            iteracion++;
        } while (iteracion < 3); // pasen 3 iteaciones sin mejora);
        return solucionActual;
    }
    
    public double steepestHillClimbing(int m,double min,double max){
        
        // m: maximo n�mero de vecinos que se crear�n 
        int iteraciones = 0;
        double solucionActual = generaSolucionAleatoria(min,max);
        double solucionNueva;
        do {            
            double solucionTemporal = generaSolucion(solucionActual,min,max);
            for (int i = 0; i < m; i++) {
                solucionNueva = generaSolucion(solucionActual,min,max);
                if (f(solucionTemporal) < f(solucionNueva))
                    solucionTemporal = solucionActual;
            }
            if (f(solucionTemporal) > f(solucionActual)) {
                solucionActual = solucionTemporal;
            }
            iteraciones ++;
        } while (iteraciones < 3);
        return solucionActual;
    }
    
    public double stepestHillClimbingReplacemenet(int m,double min,double max){
        int iteraciones = 0;
        double solucionActual = generaSolucionAleatoria(min, max);
        double mejor = solucionActual;
        double solucionNueva;
        double solucionTemporal;
        
        do {            
            solucionTemporal = generaSolucion(solucionActual, min, max);
            for (int i = 0; i < m; i++) {
                solucionNueva = generaSolucion (solucionActual, min, max);
                if (f(solucionNueva) > f(solucionTemporal)) {
                        solucionTemporal = solucionNueva;
                    }
            }
            solucionActual = solucionTemporal;
            if (f(solucionActual) > f(mejor)) {
                mejor = solucionActual;
            }
            iteraciones ++;
        } while (iteraciones < 3);
        return mejor;
    }
    
    public double generaSolucionAleatoria(double min, double max){
        double solucion = f((double) (Math.random() * max) + min);
        return solucion;
    }
    
    public double generaSolucion(double solucion, double min, double max){
        
        return 0;
    }
    
    public double f (double valor){
        //
        return 0;
    }
}
